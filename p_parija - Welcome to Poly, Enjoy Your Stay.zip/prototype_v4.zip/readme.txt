Pratik Parija, Raymond Chu

Title: Welcome to Poly, Enjoy your Stay

genre: social, interactive

Description: You try to socialize with people or go to class and get smart.

Gameplay: To play you use the directions and to talk you use spacebar.

Platform: Processing